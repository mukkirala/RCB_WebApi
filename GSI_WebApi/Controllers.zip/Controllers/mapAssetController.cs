﻿using GSI_WebApi.Models;
using System;
using System.Data.SqlClient;
using System.Net;
using System.Web.Configuration;
using System.Web.Http;

namespace GSI_WebApi.Controllers
{
    public class mapAssetController : ApiController
    {
        [HttpPost]
        public IHttpActionResult mapAsset(AssetPositions data)
        {
            if (data == null || data.AssetID <= 0 || string.IsNullOrEmpty(data.rfidTag))
            {
                return BadRequest("Invalid input data.");
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["NRLSAPConnectionString"].ConnectionString))
                {
                    string sqlState = "UPDATE AssetMaster SET RFIDCardNumber=@RFIDCardNumber, RFIDMAPDATE=@RFIDMAPDATE WHERE AssetID=@AssetID and SLNO=@SLNO";
                    using (SqlCommand cmd = new SqlCommand(sqlState, conn))
                    {
                        cmd.Parameters.AddWithValue("@RFIDCardNumber", data.rfidTag);
                        cmd.Parameters.AddWithValue("@RFIDMAPDATE", DateTime.Now);
                        cmd.Parameters.AddWithValue("@AssetID", data.AssetID);
                        cmd.Parameters.AddWithValue("@SLNO", data.slno);

                        conn.Open();
                        cmd.ExecuteNonQuery();
                    }
                }

                return Ok("1");
            }
            catch (SqlException ex)
            {
                return InternalServerError(ex); // Returns a 500 Internal Server Error with the exception details
            }
            catch (Exception ex)
            {
                return InternalServerError(ex); // Returns a 500 Internal Server Error with the exception details
            }
        }
    }
}
